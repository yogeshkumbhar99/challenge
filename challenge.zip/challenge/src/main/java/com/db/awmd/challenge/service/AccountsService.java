package com.db.awmd.challenge.service;

import java.math.BigDecimal;
import java.net.SocketTimeoutException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.ErrorCode;
import com.db.awmd.challenge.domain.TransferRequest;
import com.db.awmd.challenge.exception.AccountNotExistException;
import com.db.awmd.challenge.exception.CheckBalanceException;
import com.db.awmd.challenge.exception.OverDraftException;
import com.db.awmd.challenge.exception.SystemException;
import com.db.awmd.challenge.repository.AccountsRepository;

import lombok.Getter;

@Service
public class AccountsService {

  @Getter
  private final AccountsRepository accountsRepository;

  @Autowired
  public AccountsService(AccountsRepository accountsRepository) {
    this.accountsRepository = accountsRepository;
  }

  public void createAccount(Account account) {
    this.accountsRepository.createAccount(account);
  }

  public Account getAccount(String accountId) {
    return this.accountsRepository.getAccount(accountId);
  }
  public BigDecimal checkBalance(String string) throws SystemException {
		
		try {
			ResponseEntity<Account> balanceCheckResult = this.retrieveBalances(string);
			
			if(balanceCheckResult.getStatusCode().is2xxSuccessful()) {
				if(balanceCheckResult.hasBody()) {
					return balanceCheckResult.getBody().getBalance();
				}
			}
		} catch (ResourceAccessException ex) {
			final String errorMessage = "Encounter timeout error, please check with system administrator.";
			
			if(ex.getCause() instanceof SocketTimeoutException) {
				throw new CheckBalanceException(errorMessage, ErrorCode.TIMEOUT_ERROR);
			}
		}
		// for any other fail cases
		throw new SystemException("Encounter internal server error, please check with system administrator.", ErrorCode.SYSTEM_ERROR);
	}
  // Main Logic
	public void transferBalances(TransferRequest transfer) throws OverDraftException, AccountNotExistException, SystemException {
		//Account accountFrom = Optional.of(this.getAccount(String.valueOf(transfer.getAccountFromId())))
		//		.orElseThrow(() -> new AccountNotExistException("Account with id:" + transfer.getAccountFromId() + " does not exist.", ErrorCode.ACCOUNT_ERROR));
		Account accountFrom = this.getAccount(transfer.getAccountFromId());
		System.out.println("accountFrom " + accountFrom);
		
		//Account accountTo = Optional.of(this.getAccount(String.valueOf(transfer.getAccountToId())))
		//		.orElseThrow(() -> new AccountNotExistException("Account with id:" + transfer.getAccountFromId() + " does not exist.", ErrorCode.ACCOUNT_ERROR));
		Account accountTo = this.accountsRepository.getAccount(transfer.getAccountToId());
		
		if(accountFrom.getBalance().compareTo(transfer.getAmount()) < 0) {
			throw new OverDraftException("Account with id:" + accountFrom.getAccountId() + " does not have enough balance to transfer.", ErrorCode.ACCOUNT_ERROR);
		}
		
		accountFrom.setBalance(accountFrom.getBalance().subtract(transfer.getAmount()));
		accountTo.setBalance(accountTo.getBalance().add(transfer.getAmount()));
	}
  	
  	public ResponseEntity<Account> retrieveBalances(String string) {
		Account account = Optional.of(this.getAccount(String.valueOf(string)))
		.orElseThrow(() -> new AccountNotExistException("Account with id:" + string + " does not exist.", ErrorCode.ACCOUNT_ERROR, HttpStatus.NOT_FOUND));
		
		return ResponseEntity.ok(account);
	}
}
